# BWAMov
ini adalah project class build with angga bersama robby dianputra, kelas ini membahas mengenai cara mendevelopment aplikasi android mulai dari design

## Fiture
1. Splashscreen
2. Onboarding
3. SignIn dan SignUp
4. Home

## Teknologi
1. Firebase

## Source
Robby Dianputra
